package com.MakerStudioDemo;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class DiscoveryActivity extends ListActivity {
	private Handler _handler = new Handler();

	/* 取得默认的蓝牙适配器 */
	private BluetoothAdapter _bluetooth = BluetoothAdapter.getDefaultAdapter();

	/* 用来存储搜索到的蓝牙设备 */
	private List<BluetoothDevice> _devices = new ArrayList<BluetoothDevice>();

	public static String EXTRA_DEVICE_ADDRESS = "device_address";

	ProgressDialog SearchDialog;

	/* 是否完成搜索 */
	private volatile boolean _discoveryFinished;

	private String tishi = "Bluetooth";

	private Runnable _discoveryWorkder = new Runnable() {
		public void run() {

			System.out.println("startDiscovery");

			/* 开始搜索 */
			_bluetooth.startDiscovery();

			for (;;) {
				if (_discoveryFinished) {
					SearchDialog.cancel();
					_bluetooth.cancelDiscovery();
					showDevices(1);
					break;
				}
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {

				}
			}
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:

			setResult(RESULT_CANCELED);

			finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * 接收器 当发现蓝牙设备立即被调用。
	 */

	private BroadcastReceiver _foundReceiver = new BroadcastReceiver() {
		public void onReceive(Context context, Intent intent) {

			System.out.println("_foundReceiver onReceive");

			/* 从intent中取得搜索结果数据 */
			BluetoothDevice device = intent
					.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

			/* 将结果添加到列表中 */
			_devices.add(device);

			/* 显示列表 */
			showDevices(0);

			String strname = device.getName().toLowerCase();
			System.out.println(strname);
		}
	};

	/**
	 * 接收器 当搜索蓝牙设备完成时调用
	 */
	private BroadcastReceiver _discoveryReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			System.out.println("_discoveryReceiver onReceive");

			/* 卸载注册的接收器 */
			unregisterReceiver(_foundReceiver);
			unregisterReceiver(this);

			_discoveryFinished = true;
		}
	};

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		setContentView(R.layout.discovery);

		/* 如果蓝牙适配器没有打开，则 */

		if (!_bluetooth.isEnabled()) {

			finish();
			return;
		}

		/* 注册接收器 */
		IntentFilter discoveryFilter = new IntentFilter(
				BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
		registerReceiver(_discoveryReceiver, discoveryFilter);

		IntentFilter foundFilter = new IntentFilter(
				BluetoothDevice.ACTION_FOUND);
		registerReceiver(_foundReceiver, foundFilter);

		/* 显示一个对话框,正在搜索蓝牙设备 */
		SearchDialog = new ProgressDialog(DiscoveryActivity.this);
		SearchDialog.setMessage("searching the bluetooth device...");
		SearchDialog.show();
		new Thread(_discoveryWorkder).start();
	}

	/* 显示列表 */
	protected void showDevices(int flag) {
		List<String> list = new ArrayList<String>();

		for (int i = 0, size = _devices.size(); i < size; ++i) {
			StringBuilder b = new StringBuilder();
			BluetoothDevice d = _devices.get(i);

			b.append(d.getAddress()); // 显示地址
			b.append('\n');

			b.append(d.getName()); // 显示名称

			String s = b.toString();
			list.add(s);

		}

		if (flag == 1) {
			list.add(tishi);
		}

		final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, list);
		_handler.post(new Runnable() {
			public void run() {

				setListAdapter(adapter);
			}
		});
	}

	protected void onListItemClick(ListView l, View v, int position, long id) {

		String str = (String) l.getItemAtPosition(position);

		if (str.equals(tishi)) {
			setResult(RESULT_CANCELED);
			finish();
			return;
		}

		Intent result = new Intent();
		result.putExtra(BluetoothDevice.EXTRA_DEVICE, _devices.get(position));
		setResult(RESULT_OK, result);
		finish();
	}
}
