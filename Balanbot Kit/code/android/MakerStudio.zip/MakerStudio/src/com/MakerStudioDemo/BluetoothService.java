package com.MakerStudioDemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.UUID;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class BluetoothService {
	private static final String TAG = "BluetoothService";
	private static final UUID MY_UUID = UUID
			.fromString("00001101-0000-1000-8000-00805F9B34FB");
	private Thread t;
	private BluetoothDevice device;
	private BluetoothDevice device1;
	private BluetoothSocket btSocket;
	private boolean flag = true;
	private int linkState;
	static BufferedReader mBufferedReaderClient = null;
	private Handler handler;
	
	private BluetoothAdapter mBluetoothAdapter = null;
	//private String address = "00:12:08:29:34:06"; // HC05蓝牙模块MAC地址
	//private String address = "00:12:11:13:18:36";
	private String address = "00:12:11:13:19:36"; // HC05蓝牙模块MAC地址-9600
	
	byte[] bufferedReaderClient = new byte[512];
	int bufferedReaderClient_Counter = 0;

	public BluetoothService(BluetoothDevice device, Handler handler) {
		this.handler = handler;
		this.device = device;
		flag = true;
		t = new Thread(r);
	}

	public void connectBT() {		
		//mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (flag) {
			t.start();
			flag = false;
		}
	}

	private Runnable r = new Runnable() {
		public void run() {
			//device1 = mBluetoothAdapter.getRemoteDevice(address);
			try {
				//btSocket = device1.createRfcommSocketToServiceRecord(MY_UUID);
				btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
				btSocket.connect();
				linkState = 1;
			} catch (IOException e) {
				e.printStackTrace();
				try {
					btSocket.close();
				} catch (IOException e2) {

				}
			}
			while (linkState == 1) {
				byte[] buffer = new byte[512];
				int count = 0;
				InputStream inputStream;
				try {
					inputStream = btSocket.getInputStream();
					byte[] receivebuffer = new byte[512];
					if ((count = inputStream.read(buffer)) > 0) {
						byte[] tmp = new byte[count];
						System.arraycopy(buffer, 0, tmp, 0, count);
						for (int tmp_Counter = 0; tmp_Counter < tmp.length; tmp_Counter++) {
							bufferedReaderClient[bufferedReaderClient_Counter] = tmp[tmp_Counter];						
							if (tmp[tmp_Counter] == 0x0a) {
								int receivebuffer_Conter = bufferedReaderClient_Counter-3;
								if(receivebuffer_Conter<0)
									receivebuffer_Conter+=512;
								for(int i=0;i<2;i++){
									receivebuffer[i] = bufferedReaderClient[receivebuffer_Conter];
									receivebuffer_Conter++;
									if(receivebuffer_Conter==512)
										receivebuffer_Conter=0;						
								}
								byte[] receiveData = new byte[1];
								ascii_2_hex(receivebuffer, receiveData, 2);// 将接收到的数据转化为真实数据
								Message msg = new Message();
								msg.obj = receiveData;
								msg.what = 1;
								handler.sendMessage(msg);
							}
							bufferedReaderClient_Counter++;
							if(bufferedReaderClient_Counter==512)
								bufferedReaderClient_Counter = 0;				
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		
		}
	};

	public void sendCmd(byte[] msgBuffer) {
		OutputStream outStream = null;
		try {
			outStream = btSocket.getOutputStream();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// byte[] msgBuffer;
		// msgBuffer = message.getBytes();
		try {
			outStream.write(msgBuffer);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void sendCmd1(byte[] msgBuffer) {
		int msgBuffer_Counter = msgBuffer.length;
		byte[] TempBuffer = new byte[msgBuffer_Counter * 2];
		hex_2_ascii(msgBuffer, TempBuffer, msgBuffer_Counter);// 数据格式转化
		byte[] OutPutBuffer = new byte[TempBuffer.length + 3];
		OutPutBuffer[0] = 0x01;// 添加起始符
		OutPutBuffer[TempBuffer.length + 2] = 0x0a;// 添加结束符
		OutPutBuffer[TempBuffer.length + 1] = 0x0d;// 添加结束符
		for (int i = 0; i < TempBuffer.length; i++) {
			OutPutBuffer[i] = TempBuffer[i];
		}
		OutputStream outStream = null;
		try {
			outStream = btSocket.getOutputStream();
			outStream.write(OutPutBuffer);
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

	private String getInfoBuff(char[] buff, int count) {
		char[] temp = new char[count];
		for (int i = 0; i < count; i++) {
			temp[i] = buff[i];
		}
		return new String(temp);
	}
	
	//*****************************************
	//HEX 到 ASCII 的转换函数
	//入口参数： data: 转换数据输入
	//buffer: 转换数据输出
	//len : 需要转换的长度
	//返回参数：转换后数据长度

	int hex_2_ascii(byte[] data, byte[] buffer, int len) {
		int i, pos;
		byte[] ascTable = new byte[16];
		ascTable[0] = 0x30;
		ascTable[1] = 0x31;
		ascTable[2] = 0x32;
		ascTable[3] = 0x33;
		ascTable[4] = 0x34;
		ascTable[5] = 0x35;
		ascTable[6] = 0x36;
		ascTable[7] = 0x37;
		ascTable[8] = 0x38;
		ascTable[9] = 0x39;
		ascTable[10] = 0x41;
		ascTable[11] = 0x42;
		ascTable[12] = 0x43;
		ascTable[13] = 0x44;
		ascTable[14] = 0x45;
		ascTable[15] = 0x46;

		pos = 0;
		for (i = 0; i < len; i++) {
			if (data[i] == 0) {
				buffer[pos] = 0x00;
				return i;
			}
			buffer[pos++] = ascTable[data[i] >> 4];
			buffer[pos++] = ascTable[data[i] & 0x0f];
		}
		return pos;
	}
	
	//*****************************************
	//ASCII 到 HEX 的转换函数
	//入口数据： O_buf: 转换数据的入口指针，
	//N_buf: 转换后新数据
	//len : 需要转换的长度
	//返回参数：-1: 转换失败
	//其它：转换后数据长度
	//注意：O_buf[]数组中的数据在转换过程中会被修改。

	int ascii_2_hex(byte[] O_buf, byte[] N_buf, int len)
	{
		int i,j,tmp_len;
		byte tmpData = 0;
		for(i = 0; i < len; i++)
		{
			if ((O_buf[i] >= 0x30) && (O_buf[i] <= 0x39))
			{     
				tmpData = (byte)(O_buf[i] - 0x30);
			}else if ((O_buf[i] >= 0x41) && (O_buf[i] <= 0x46)) //A....F
			{
				tmpData = (byte)(O_buf[i] - 0x37);
			}
			else if((O_buf[i] >= 0x61) && (O_buf[i] <= 0x66)) //a....f
			{
				tmpData = (byte)(O_buf[i] - 0x57);
			}
			else
			{
				break;
			}
			O_buf[i] = tmpData;
		}
		for(tmp_len = 0,j = 0; j < i; j+=2)
		{
			N_buf[tmp_len] = (byte)((O_buf[j]<<4) | O_buf[j+1]);
			tmp_len++;
		}
		return tmp_len;
	}

}
