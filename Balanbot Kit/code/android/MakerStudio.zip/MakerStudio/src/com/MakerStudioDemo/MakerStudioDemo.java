package com.MakerStudioDemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.UUID;

import com.MakerStudioDemo.DiscoveryActivity;
import com.MakerStudioDemo.PIDSet;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;


public class MakerStudioDemo extends Activity {
	/* Called when the activity is first created. */

	private Button BTStart;
	private Button ACCStart;
	private Button Vocie;
	private Button Forward;  
	private Button Back;
	private Button Left;
	private Button Right;
	private Button Stop;
	private Button Shoot;
	private TextView RecvText;
	private SeekBar seekBarPWM;
	private BluetoothDevice device;
	private static BluetoothService bluetoothService;
	private BluetoothSocket btSocket = null;

	private Context mContext;
	private static MakerStudioDemo mContext1;

	private Thread BTThread = null;
	static BufferedReader mBufferedReaderServer = null;
	static PrintWriter mPrintWriterServer = null;
	static BufferedReader mBufferedReaderClient = null;
	static PrintWriter mPrintWriterClient = null;
	private String recvMessageClient = "";
	private String recvMessageServer = "";

	private static final int REQUEST_DISCOVERY = 2;

	private int DiscoveryState = 0;
	private int BTStartstate = 0;
	private int Linkstate = 0;
	
	private SensorManager mSensorManager;
	
	private int azimuth;
	private int pitch;
	private int roll;
	private char height;

	byte[] commandPacket = new byte[11];
	byte[] commandPacket1 = new byte[2];
	byte[] commandPacket2 = new byte[4];
	static byte[] commandPacketBlueTooth = new byte[6];
	float pwm1, pwm2;
	private String TAG = "duzhipeng";

	private static String address = "00:12:08:29:34:06"; // <==Ҫ���ӵ������豸MAC��ַ
	public boolean BluetoothFlag = true;
	private BluetoothAdapter mBluetoothAdapter = null;
	private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
	private OutputStream outStream = null;
	private InputStream inputStream = null;
	
	public static int KAngle = 56;
	public static int KAngleSpeed = 47;
	public static int KPosition = 80;
	public static int KPositionSpeed = 60;
	public static int KBaseAngle = 23;
	
	private Button Voice;//自平衡参数修改
	private View menuView;
	private int speed1;
	private int speed2;
	static TextView textView_Speed1;
	static TextView textView_Speed2;
	static SeekBar seekBar_Speed1;
	static SeekBar seekBar_Speed2;
	
	private Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			// super.handleMessage(msg);
			if (msg.what == 1) {
				//Log.d("duzhipeng", "msg"  + "\n");
				//float [] chanal = new float[2];
				//clientValue为从客户端获得的电压值
				byte[] clientValue = (byte[]) msg.obj;
				for(int clientValue_Counter=0;clientValue_Counter<clientValue.length;clientValue_Counter++){
					int value = clientValue[clientValue_Counter]&0xFF;
					Log.d("duzhipeng", "clientValue"  + value + "\n");
					if(value == 48){
					//USBCommandPacket[0] = 5;//控制方式1：PWM直接控制
					//USBCommandPacket[5] = 5;//控制方式1：PWM直接控制
					//USBCommandPacket[6] = 1;//控制方式1：PWM直接控制
					//accessoryManager.write(USBCommandPacket);
						commandPacket[0] = 0x30;
						commandPacket[1] = 0x36;
						commandPacket[2] = 0x30;//0x33//0x30
						commandPacket[3] = 0x34;//0x30//0x32
						commandPacket[4] = 0x0d;
						commandPacket[5] = 0x0a;
						bluetoothService.sendCmd(commandPacket);
					}
					if(value == 49){
					//USBCommandPacket[0] = 5;//控制方式1：PWM直接控制
					//USBCommandPacket[5] = 5;//控制方式1：PWM直接控制
					//USBCommandPacket[6] = 1;//控制方式1：PWM直接控制
					//accessoryManager.write(USBCommandPacket);
						commandPacket[0] = 0x30;
						commandPacket[1] = 0x41;
						commandPacket[2] = 0x30;
						commandPacket[3] = 0x32;
						commandPacket[4] = 0x0d;
						commandPacket[5] = 0x0a;
						bluetoothService.sendCmd(commandPacket);
					}
				}
				//clientValue为字节数据，长度理论上位8个字节，根据规则计算出两个通道的电压值------>阿杜在下面添加计算两个通道电压的代码
				//int result2 = clientValue[2]&0xFF;
				//int result3 = clientValue[3]&0xFF;
				//int result4 = clientValue[4]&0xFF;
				//int result5 = clientValue[5]&0xFF;
				//chanal[0] = 3.3f*(clientValue[2]*255+clientValue[3])/1024;
				//chanal[1] = 3.3f*(clientValue[4]*255+clientValue[5])/1024;

				
				//把计算得到的两个通道的电压值作为参数进行绘图操作
				//dataInterface.dataChanged(chanal[0],chanal[1]);
			}
		}

	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		mContext = this;
		mContext1 = this;
		
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
		.detectDiskReads()
		.detectDiskWrites()
		.detectNetwork() // or .detectAll() for all detectable problems
		.penaltyLog()
		.build());
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
		.detectLeakedSqlLiteObjects()
		.penaltyLog()
		.penaltyDeath()
		.build());
		commandPacket[0] = (byte) 0xFF;
		commandPacket[1] = (byte) 0xAA;
		commandPacket[2] = 0x00;
		commandPacket[3] = 0x00;
		commandPacket[4] = 0x00;
		commandPacket[5] = 0x00;
		commandPacket[8] = 0x00;
		commandPacket[9] = 0x00;
		commandPacket[10] = 0x02;
		commandPacket1[0] = 0x30;
		commandPacket1[1] = 0x30;
		commandPacketBlueTooth[0] = (byte)0xAA;
	
		Intent discoverrs = new Intent(this, DiscoveryActivity.class);
		startActivityForResult(discoverrs, REQUEST_DISCOVERY);  
		
		textView_Speed1 = (TextView)findViewById(R.id.textView_Speed1);
		textView_Speed2 = (TextView)findViewById(R.id.textView_Speed2);
		
		seekBar_Speed1 = (SeekBar)findViewById(R.id.seekBar_Speed1);
		seekBar_Speed1.setMax(100);
		//seekBar_Speed1.setProgress(MakerStudioDemo.getKAngle());
		
		seekBar_Speed2 = (SeekBar) findViewById(R.id.seekBar_Speed2);
		seekBar_Speed2.setMax(100);
		//seekBar_Speed2.setProgress(MakerStudioDemo.getKAngleSpeed());
		
		// 设置拖动条改变监听器
		OnSeekBarChangeListener seekBar_Speed1_Listener = new OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				//App.setKAngle(seekBar_KAngle.getProgress());
				textView_Speed1.setText("Speed1" + seekBar_Speed1.getProgress());
				speed1 = seekBar_Speed1.getProgress();
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// Toast.makeText(getApplicationContext(), "onStopTrackingTouch",Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// Toast.makeText(getApplicationContext(), "onStopTrackingTouch",Toast.LENGTH_SHORT).show();
			}

		};
		// 为拖动条绑定监听器
		seekBar_Speed1.setOnSeekBarChangeListener(seekBar_Speed1_Listener);	
		
		// 设置拖动条改变监听器
		OnSeekBarChangeListener seekBar_Speed2_Listener = new OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				textView_Speed2.setText("Speed2=" + seekBar_Speed2.getProgress()*3);
				speed2 = seekBar_Speed2.getProgress()*3;
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// Toast.makeText(getApplicationContext(), "onStopTrackingTouch",Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// Toast.makeText(getApplicationContext(), "onStopTrackingTouch",Toast.LENGTH_SHORT).show();
			}

		};
		// 为拖动条绑定监听器
		seekBar_Speed2.setOnSeekBarChangeListener(seekBar_Speed2_Listener);	
		
		mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		
		LayoutInflater mLayoutInflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		menuView = (View) mLayoutInflater.inflate(
				R.layout.main, null, true);		

		BTStart = (Button) findViewById(R.id.BTStart);
		BTStart.setOnClickListener(BTStartClickListener);
		
		Voice = (Button) findViewById(R.id.Voice);
		Voice.setOnClickListener(VoiceClickListener);
		
		Forward = (Button) findViewById(R.id.Forward);
		Forward.setOnTouchListener(new Button.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int action = event.getAction();
				switch (action) {
				case MotionEvent.ACTION_DOWN:
					commandPacketBlueTooth[1] = 0x03;
					commandPacketBlueTooth[2] = 0x01;
					commandPacketBlueTooth[3] = 0x03;
					commandPacketBlueTooth[4] = (byte)speed1;
					commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
					bluetoothService.sendCmd(commandPacketBlueTooth);
					break;

				case MotionEvent.ACTION_UP:
					commandPacketBlueTooth[1] = 0x03;
					commandPacketBlueTooth[2] = 0x00;
					commandPacketBlueTooth[3] = 0x03;
					commandPacketBlueTooth[4] = 30;
					commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
					bluetoothService.sendCmd(commandPacketBlueTooth);
					break;
				}
				return false;
			}
		});

		
		Back = (Button) findViewById(R.id.Back);
		Back.setOnTouchListener(new Button.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int action = event.getAction();
				switch (action) {
				case MotionEvent.ACTION_DOWN:
					commandPacketBlueTooth[1] = 0x03;
					commandPacketBlueTooth[2] = 0x02;
					commandPacketBlueTooth[3] = 0x00;
					commandPacketBlueTooth[4] = (byte)speed1;
					commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
					bluetoothService.sendCmd(commandPacketBlueTooth);
					break;

				case MotionEvent.ACTION_UP:
					commandPacketBlueTooth[1] = 0x03;
					commandPacketBlueTooth[2] = 0x00;
					commandPacketBlueTooth[3] = 0x00;
					commandPacketBlueTooth[4] = 0x30;
					commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
					bluetoothService.sendCmd(commandPacketBlueTooth);
					break;
				}
				return false;
			}
		});

		Left = (Button) findViewById(R.id.Left);
		Left.setOnTouchListener(new Button.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int action = event.getAction();
				switch (action) {
				case MotionEvent.ACTION_DOWN:
					commandPacketBlueTooth[1] = 0x03;
					commandPacketBlueTooth[2] = 0x03;
					commandPacketBlueTooth[3] = 0x00;
					commandPacketBlueTooth[4] = (byte)speed2;
					commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
					bluetoothService.sendCmd(commandPacketBlueTooth);
					break;

				case MotionEvent.ACTION_UP:
					commandPacketBlueTooth[1] = 0x03;
					commandPacketBlueTooth[2] = 0x00;
					commandPacketBlueTooth[3] = 0x03;
					commandPacketBlueTooth[4] = 0x03;
					commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
					bluetoothService.sendCmd(commandPacketBlueTooth);
					break;
				}
				return false;
			}
		});

		Right = (Button) findViewById(R.id.Right);
		Right.setOnTouchListener(new Button.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int action = event.getAction();
				switch (action) {
				case MotionEvent.ACTION_DOWN:
					commandPacketBlueTooth[1] = 0x03;
					commandPacketBlueTooth[2] = 0x04;
					commandPacketBlueTooth[3] = 0x7F;
					commandPacketBlueTooth[4] = (byte)speed2;
					commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
					bluetoothService.sendCmd(commandPacketBlueTooth);
					break;

				case MotionEvent.ACTION_UP:
					commandPacketBlueTooth[1] = 0x03;
					commandPacketBlueTooth[2] = 0x00;
					commandPacketBlueTooth[3] = 0x03;
					commandPacketBlueTooth[4] = 0x03;
					commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
					bluetoothService.sendCmd(commandPacketBlueTooth);
					break;
				}
				return false;
			}
		});

		Stop = (Button) findViewById(R.id.Stop);
		Stop.setOnTouchListener(new Button.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int action = event.getAction();
				switch (action) {
				case MotionEvent.ACTION_DOWN:
					commandPacket[0] = 0x30;
					commandPacket[1] = 0x41;
					commandPacket[2] = 0x30;
					commandPacket[3] = 0x32;
					commandPacket[4] = 0x0d;
					commandPacket[5] = 0x0a;
					bluetoothService.sendCmd(commandPacket);
					break;

				case MotionEvent.ACTION_UP:
					commandPacketBlueTooth[1] = 0x03;
					commandPacketBlueTooth[2] = 0x00;
					commandPacketBlueTooth[3] = 0x03;
					commandPacketBlueTooth[4] = 0x03;
					commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
					bluetoothService.sendCmd(commandPacketBlueTooth);
					break;
				}
				return false;
			}
		});

		/*
		Shoot = (Button) findViewById(R.id.Shoot);
		Shoot.setOnTouchListener(new Button.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int action = event.getAction();
				switch (action) {
				case MotionEvent.ACTION_DOWN:
					commandPacket[0] = 0x30;
					commandPacket[1] = 0x42;
					commandPacket[2] = 0x30;
					commandPacket[3] = 0x32;
					commandPacket[4] = 0x0d;
					commandPacket[5] = 0x0a;
					bluetoothService.sendCmd(commandPacket);
					break;

				case MotionEvent.ACTION_UP:
					commandPacket[0] = 0x30;
					commandPacket[1] = 0x43;
					commandPacket[2] = 0x30;
					commandPacket[3] = 0x32;
					commandPacket[4] = 0x0d;
					commandPacket[5] = 0x0a;
					bluetoothService.sendCmd(commandPacket);
					break;
				}
				return false;
			}
		});
		*/
		
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (mBluetoothAdapter == null) {
			finish();
			return;
		}

		if (!mBluetoothAdapter.isEnabled()) {
			finish();
			return;
		}
	}

	private OnClickListener VoiceClickListener = new OnClickListener() {
		@Override
		public void onClick(View arg0) {
			//WIFIRobotControl.showAlgoPIDComponentDlg(mContext, menuView);
			//WIFI_Control_CommandPacket[0] = 0x0A;//喜欢
			//if (Linkstate == 1)
			//	sendCmd(WIFI_Control_CommandPacket);

			textView_Speed1.setVisibility(View.INVISIBLE);
			textView_Speed2.setVisibility(View.INVISIBLE);
			seekBar_Speed1.setVisibility(View.INVISIBLE);
			seekBar_Speed2.setVisibility(View.INVISIBLE);
			PIDSet.showPIDSetDialog(mContext, menuView);
		}
	};

	private OnClickListener BTStartClickListener = new OnClickListener() {
		@Override
		public void onClick(View arg0) {
			BTStartstate = 1;
		}
	};

	private SensorEventListener mSensorEventListener = new SensorEventListener() {
		@Override
		public void onSensorChanged(SensorEvent event) {
			
			azimuth = (int)event.values[SensorManager.DATA_X];
			pitch = (int)event.values[SensorManager.DATA_Y];
			roll = (int)event.values[SensorManager.DATA_Z];
			
			char rotation = (char)(azimuth - 200);
			char stretch = (char)(pitch + 100);
			commandPacket[2] = (byte) (rotation >>> 8);
			commandPacket[3] = (byte) (rotation);
			commandPacket[4] = (byte) (stretch >>> 8);
			commandPacket[5] = (byte) (stretch);
			
			if(BTStartstate == 1){
				bluetoothService.sendCmd(commandPacket);
			}
		}
		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {

		}
	};
	
	public void onResume() {
		super.onResume();
		mSensorManager.registerListener(mSensorEventListener,
				mSensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
				SensorManager.SENSOR_DELAY_NORMAL);
	}

	public void onPause() {
			if (BTStartstate == 1) {
				BTThread.interrupt();
				if (outStream != null) {
					try {
						outStream.flush();
					} catch (IOException e) {
						Log.e(TAG, "ON PAUSE: Couldn't flush output stream.", e);
					}
				}
				try {
					btSocket.close();
				} catch (IOException e2) {
					DisplayToast("�׽��ֹر�ʧ�ܣ�");
				}
				BTStart.setText("��������");
				BTStartstate = 0;
			}
		super.onPause();

	}

	public void onDestroy() {
		super.onDestroy();
	}

	@Override
	public boolean onKeyDown (int keyCode, KeyEvent event) {
	// 获取手机当前音量值
	//int i = getCurrentRingValue ();
	switch (keyCode) {
	// 音量减小
	case KeyEvent.KEYCODE_VOLUME_DOWN:
	Log.d(TAG, "KEYCODE_VOLUME_DOWN:" + "\n");
	//Toast.makeText (Activity03.this, "当前音量值： " + i, Toast.LENGTH_SHORT).show ();
	return true;
	// 音量增大
	case KeyEvent.KEYCODE_VOLUME_UP:
	Log.d(TAG, "KEYCODE_VOLUME_UP:" + "\n");
	int speed = 120;
	commandPacket[0] = 0x30;
	commandPacket[1] = 0x42;
	commandPacket[2] = 0x30;
	commandPacket[3] = 0x32;
	commandPacket[4] = 0x0d;
	commandPacket[5] = 0x0a;
	bluetoothService.sendCmd(commandPacket);
	return true;
	}
	return super.onKeyDown (keyCode, event);
	}
	
	@Override
	public boolean onKeyUp (int keyCode, KeyEvent event) {
	// 获取手机当前音量值
	//int i = getCurrentRingValue ();
	switch (keyCode) {
	// 音量减小
	case KeyEvent.KEYCODE_VOLUME_DOWN:
	Log.d(TAG, "KEYCODE_VOLUME_DOWNUP:" + "\n");
	//Toast.makeText (Activity03.this, "当前音量值： " + i, Toast.LENGTH_SHORT).show ();
	return true;
	// 音量增大
	case KeyEvent.KEYCODE_VOLUME_UP:
		int speed = 0;
		commandPacket[0] = 0x30;
		commandPacket[1] = 0x43;
		commandPacket[2] = 0x30;
		commandPacket[3] = 0x32;
		commandPacket[4] = 0x0d;
		commandPacket[5] = 0x0a;
		bluetoothService.sendCmd(commandPacket);
		Log.d(TAG, "KEYCODE_VOLUME_UPup:" + "\n");
		//Toast.makeText (Activity03.this, "当前音量值： " + i, Toast.LENGTH_SHORT).show ();
		return true;
	}
	return super.onKeyUp (keyCode, event);
	}
	
	/*
	 * Handle the results from the discovery&speech recognition activity.
	 */
	// @Overrid

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_DISCOVERY
				&& resultCode == RESULT_OK) {
		 	device = data.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
			bluetoothService = new BluetoothService(device, handler);
			bluetoothService.connectBT();
		 	DiscoveryState = 1;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	public void DisplayToast(String str) {
		Toast toast = Toast.makeText(this, str, Toast.LENGTH_SHORT);
		toast.setGravity(Gravity.TOP, 0, 220);
		toast.show();
	}

	public void sendCmd(byte[] msgBuffer) {
		try {
			outStream = btSocket.getOutputStream();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// byte[] msgBuffer;
		// msgBuffer = message.getBytes();
		try {
			outStream.write(msgBuffer);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String getInfoBuff(char[] buff, int count)
	{
		char[] temp = new char[count];
		for(int i=0; i<count; i++)
		{
			temp[i] = buff[i];
		}
		return new String(temp);
	}
	
	int hex_2_ascii(byte[] data, byte[] buffer, int len) {
		int i, pos;
		byte[] ascTable = new byte[16];
		ascTable[0] = 0x30;
		ascTable[1] = 0x31;
		ascTable[2] = 0x32;
		ascTable[3] = 0x33;
		ascTable[4] = 0x34;
		ascTable[5] = 0x35;
		ascTable[6] = 0x36;
		ascTable[7] = 0x37;
		ascTable[8] = 0x38;
		ascTable[9] = 0x39;
		ascTable[10] = 0x41;
		ascTable[11] = 0x42;
		ascTable[12] = 0x43;
		ascTable[13] = 0x44;
		ascTable[14] = 0x45;
		ascTable[15] = 0x46;

		pos = 0;
		for (i = 0; i < len; i++) {
			if (data[i] == 0) {
				buffer[pos] = 0x00;
				return i;
			}
			buffer[pos++] = ascTable[data[i] >> 4];
			buffer[pos++] = ascTable[data[i] & 0x0f];
		}
		return pos;
	}
	
	public static int getKAngle() {
		return KAngle;
	}
	
	public static void setKAngle(int kangle) {
		mContext1.KAngle = kangle;
		commandPacketBlueTooth[1] = 0x02;
		commandPacketBlueTooth[2] = 0x01;
		int angle = (kangle/2)*100;
		commandPacketBlueTooth[3] = (byte)(angle / 255);
		commandPacketBlueTooth[4] = (byte)(angle % 255);;
		//commandPacketBlueTooth[4] = 0x03;
		commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
		bluetoothService.sendCmd(commandPacketBlueTooth);
	}
	
	public static int getKAngleSpeed() {
		return KAngleSpeed;
	}
	
	public static void setKAngleSpeed(int kangleSpeed) {
		mContext1.KAngleSpeed = kangleSpeed;
		commandPacketBlueTooth[1] = 0x02;
		commandPacketBlueTooth[2] = 0x02;
		int angleSpeed = (KAngleSpeed/10)*100;
		commandPacketBlueTooth[3] = (byte)(angleSpeed / 255);
		commandPacketBlueTooth[4] = (byte)(angleSpeed % 255);;
		//commandPacketBlueTooth[4] = 0x03;
		commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
		bluetoothService.sendCmd(commandPacketBlueTooth);
	}
	
	public static int getKPosition() {
		return KPosition;
	}

	public static void setKPosition(int kposition) {
		mContext1.KPosition = kposition;
		commandPacketBlueTooth[1] = 0x04;
		commandPacketBlueTooth[2] = 0x05;
		int position = kposition;
		commandPacketBlueTooth[3] = (byte)(position / 255);
		commandPacketBlueTooth[4] = (byte)(position % 255);;
		//commandPacketBlueTooth[4] = 0x03;
		commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
		bluetoothService.sendCmd(commandPacketBlueTooth);
	}
	
	public static int getKPositionSpeed() {
		return KPositionSpeed;
	}

	public static void setKPositionSpeed(int kpositionspeed) {
		mContext1.KPositionSpeed = kpositionspeed;
		commandPacketBlueTooth[1] = 0x02;
		commandPacketBlueTooth[2] = 0x03;
		int positionSpeed = (kpositionspeed/2)*100;
		commandPacketBlueTooth[3] = (byte)(positionSpeed / 255);
		commandPacketBlueTooth[4] = (byte)(positionSpeed % 255);;
		//commandPacketBlueTooth[4] = 0x03;
		commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
		bluetoothService.sendCmd(commandPacketBlueTooth);
	}
	
	public static int getKBaseAngle() {
		return KBaseAngle;
	}

	public static void setKBaseAngle(int kbaseangle) {
		mContext1.KBaseAngle = kbaseangle;				
		commandPacketBlueTooth[1] = 0x02;
		commandPacketBlueTooth[2] = 0x05;
		int BaseAngle = (5 + kbaseangle/10)*100;
		commandPacketBlueTooth[3] = (byte)(BaseAngle / 255);
		commandPacketBlueTooth[4] = (byte)(BaseAngle % 255);;
		//commandPacketBlueTooth[4] = 0x03;
		commandPacketBlueTooth[5] = exclusiveOr(commandPacketBlueTooth);
		bluetoothService.sendCmd(commandPacketBlueTooth);
	}
	
	public static void setVisible() {
		textView_Speed1.setVisibility(View.VISIBLE);
		textView_Speed2.setVisibility(View.VISIBLE);
		seekBar_Speed1.setVisibility(View.VISIBLE);
		seekBar_Speed2.setVisibility(View.VISIBLE);
	}
	
	public static byte exclusiveOr(byte[] commandPacket) {
		Byte result = null;
		return result = (byte) (commandPacket[2] ^ commandPacket[3] ^ commandPacket[4]);
		
	}
}